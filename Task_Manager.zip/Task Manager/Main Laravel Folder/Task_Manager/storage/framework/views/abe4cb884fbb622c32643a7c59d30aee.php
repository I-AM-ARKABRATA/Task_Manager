Dear <?php echo e($data->task_owner); ?>, <br><br>
The Task <?php echo e($data->task_description); ?>, <?php echo e($data->status?"has been Marked as Completed.":"has been assigned to you."); ?> <br><br>
<?php if(!$data->status): ?>
Kindly complete it within <?php echo e($data->task_eta); ?><br><br>
<?php endif; ?>
Thank you.<?php /**PATH C:\Users\user\OneDrive\Desktop\Task Manager\Task_Manager\resources\views/emailsender/notification.blade.php ENDPATH**/ ?>