<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TaskManager;
use App\Jobs\sendemail;

class TaskController extends Controller
{
    public function create(Request $request){
        $data = new TaskManager();
        $data->task_description =$request->get('task_description');
        $data->task_owner = $request->get('task_owner');
        $data->task_owner_email =$request->get('task_owner_email');
        $data->task_eta =$request->get('task_eta');
        if($data->save()){
            dispatch(new sendemail($data));
            return "Data saved successfully";
        }else{
            return "Something went wrong";
        }
    }
    public function getalltask(){
        $data = TaskManager::get();
        return $data;
    }
    public function gettaskbyId($id){
        $data = TaskManager::find($id);
        return $data;
    }
    public function update(Request $request, $id){
        $data = TaskManager::find($id);
        $data->task_description =$request->get('task_description');
        $data->task_owner = $request->get('task_owner');
        $data->task_owner_email =$request->get('task_owner_email');
        $data->task_eta =$request->get('task_eta');
        $data->status = $request->get('status');
        if($data->save()){
            return "Data Updated successfully";

        }else{
            return "Something went wrong";
        }
    }
    public function markasdone($id){
        $data = TaskManager::find($id);
        $data->status = 1;
        if($data->save()){
            dispatch(new sendemail($data));
            return "Data Marked as Done successfully";

        }else{
            return "Something went wrong";
        }
    }
    public function delete($id){
        $data = TaskManager::find($id);
        if($data->delete()){
            return "Data Deleted successfully";

        }else{
            return "Something went wrong";
        }
    }
}
