Dear {{$data->task_owner}}, <br><br>
The Task {{$data->task_description}}, {{$data->status?"has been Marked as Completed.":"has been assigned to you."}} <br><br>
@if(!$data->status)
Kindly complete it within {{$data->task_eta}}<br><br>
@endif
Thank you.